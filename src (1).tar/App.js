import './App.css'
import AiCorporateTraining from './components/AiCorporateTraining'

const App = () => (
  <div>
    <AiCorporateTraining />
  </div>
)

export default App
