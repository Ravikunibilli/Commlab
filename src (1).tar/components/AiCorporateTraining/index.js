import {Component} from 'react'
import './index.css'
import {AiFillCheckCircle} from 'react-icons/ai'
import {HiUserGroup} from 'react-icons/hi'

class AiCorporateTraining extends Component {
  render() {
    return (
      <div>
        <div className="first-container">
          <h3 className="first-container-heading">
            "Some people call this artificial intelligence, but the reality is
            this technology will enhance us. So, instead of artificial
            intelligence, I think we’ll augment our intelligence” - Ginni
            Rometty – Former CEO & President, IBM"
          </h3>
          <div className="container-part1">
            <img
              src="https://resources.commlabindia.com/hs-fs/hubfs/webinars/corporate-training-with-ai-banner-image.png?width=525&height=734&name=corporate-training-with-ai-banner-image.png"
              alt="girl"
              className="girl-image"
            />
            <div className="container-inline">
              <p className="inline-para">The Top Trending Topic of the Year</p>
              <h1 className="inline-heading">
                Unleashing the Potential of AI in Corporate Training
              </h1>
              <br color="black" />
              <p>
                <AiFillCheckCircle color="red" /> Learn how AI is helping
                corporates upskill and reskill workforce{' '}
              </p>
              <p>
                {' '}
                <AiFillCheckCircle color="red" /> Walk away with tips, tools,
                and resources to get started with AI-empowered training{' '}
              </p>
              <div className="inline-line">
                <p className="inline-line-para">
                  JOIN DR RK Prasad, Shalini, Rajesh LIVE
                </p>
              </div>
              <p className="inline-dates">
                Tuesday, January 09, 2024 11 AM Eastern | 8 AM Pacific Duration:
                90 Minutes $997 VALUE FREE!
              </p>
              <div className="button-container">
                <button className="button" type="button">
                  <HiUserGroup color="white" size="48px" />
                  SECURE YOUR SEAT
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default AiCorporateTraining
